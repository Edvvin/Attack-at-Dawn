var searchData=
[
  ['gen_5faux',['gen_aux',['../main_8c.html#a702d0fd694ddfb52113d0bc8bfedea09',1,'main.c']]],
  ['get_5factive_5fmenu',['get_active_menu',['../menus_8h.html#a8a1a08c1b35ce96387da229e74d3cfcf',1,'menus.c']]],
  ['get_5fcolumn',['get_column',['../menus_8h.html#adb8f3ffad2dd8d346164f93faefd471a',1,'menus.c']]],
  ['get_5ff',['get_f',['../menus_8h.html#ace9f9bc05a234c7de4122677c62fd30c',1,'menus.c']]],
  ['get_5ffield',['get_field',['../menus_8h.html#a7f5018ce8b0abea4efccfbfefe616301',1,'menus.c']]],
  ['get_5fmenu',['get_menu',['../menus_8h.html#a9bba4380cc46107173965309adc9375a',1,'menus.c']]],
  ['getpos',['getPos',['../menus_8h.html#a72bca7ce056b7716620592c3b1b19c96',1,'menus.c']]]
];
