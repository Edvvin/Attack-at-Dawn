var searchData=
[
  ['column',['COLUMN',['../menus_8h.html#a4e327d4d73bf55b137fb86ef14459f12',1,'menus.h']]],
  ['couple',['COUPLE',['../main_8c.html#adf8042d44f1a652571d12ef8091a1173',1,'main.c']]]
];
