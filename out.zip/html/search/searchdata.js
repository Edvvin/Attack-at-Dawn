var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstu",
  1: "bcfkmp",
  2: "adhkm",
  3: "abcdefghiklmnoprstu",
  4: "acfkmp",
  5: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "enums"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Typedefs",
  5: "Enumerations"
};

