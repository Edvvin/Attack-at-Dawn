var searchData=
[
  ['load',['load',['../main_8c.html#a78f61ac2dd03bcba8e09ca20cd7d68e3',1,'main.c']]],
  ['lockcolumn',['lockColumn',['../menus_8h.html#aa973fb8d4b019e7790213923a5532f96',1,'menus.c']]]
];
