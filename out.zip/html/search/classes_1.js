var searchData=
[
  ['column',['column',['../structcolumn.html',1,'']]],
  ['couple',['couple',['../structcouple.html',1,'']]]
];
