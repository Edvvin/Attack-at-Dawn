var searchData=
[
  ['batch_5fmode',['batch_mode',['../aadcmd_8h.html#a4b39215be53cfb07461841c8a47bf22b',1,'aadcmd.c']]],
  ['blok',['blok',['../structblok.html',1,'']]]
];
