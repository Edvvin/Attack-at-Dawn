var searchData=
[
  ['new_5fcolumn',['new_column',['../menus_8h.html#aeda5d204772664344c43148cfb40bb81',1,'menus.c']]],
  ['new_5ffield',['new_field',['../menus_8h.html#a095976bc12239977e698a7e145770b99',1,'menus.c']]],
  ['new_5fmenu',['new_menu',['../menus_8h.html#a88f51d69a78b154bc4817c33ed2ba7e0',1,'menus.c']]],
  ['next_5fmenu',['next_menu',['../menus_8h.html#af8cee4a435adb3050820edba4c580ba6',1,'menus.c']]],
  ['nothing',['nothing',['../menus_8h.html#a53e7e608251570bd7e9e67a2a52540d7',1,'menus.c']]],
  ['nothing2',['nothing2',['../menus_8h.html#ad353e9cbd934481cd58bb55a00c1545b',1,'menus.c']]]
];
