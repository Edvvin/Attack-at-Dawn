var searchData=
[
  ['algorithm',['algorithm',['../main_8c.html#a8a0fd7a8363e41d8c12a90716f4f500f',1,'main.c']]]
];
