var searchData=
[
  ['remove_5ffield',['remove_field',['../menus_8h.html#a93c30a442cdaa06b6b75c4122d34c4b9',1,'menus.c']]],
  ['remove_5fselected_5ffield',['remove_selected_field',['../menus_8h.html#a74f67c3c575bd9a99d5c4ebc609e4be5',1,'menus.c']]],
  ['run_5fprog',['run_prog',['../menus_8h.html#a9133c5e78d80c20c03fc859391a7e8a5',1,'menus.c']]]
];
